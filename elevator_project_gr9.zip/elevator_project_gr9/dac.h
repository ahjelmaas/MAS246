/*
* MCP_4922.h
* Library header file for MCP_4922 library
*/
#include "Arduino.h"

void dac_init(void);			    	// function prototype

void set_dac (int value_a, int value_b);  // function prototype